const request = require('request');

exports.handler = function(e, ctx, cb) {
  request.post({url:'http://192.168.1.6', form: {key:'value'}}, function(err,httpResponse,body){ /* ... */ })
};

